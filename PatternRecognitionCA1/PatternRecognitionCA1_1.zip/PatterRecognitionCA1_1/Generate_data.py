#该代码用于生成二维正态分布数据，并以不同的颜色绘制散点图，并保存数据
import matplotlib.pyplot as plt #用于绘制散点图
import numpy as np
import scipy.io as io #将数据保存为MATLAB格式，即.mat文件

N1 = 300 #第一类样本数
N2 = 80 #第二类样本数
K = 2 #特征维度，也即数据点是二维的，表示为(x1,x2)
sigma = 2 #协方差矩阵的对角值，影响数据的扩散程度

mean1 = (10, 14) #第一类数据的均值在坐标轴的(10,14)
cov1 = np.array([[sigma, 0], [0, sigma]]) #协方差矩阵，对角线方向表示x1和x2方向的方差都为2，另一方向对角线表示x1和x2之间没有相关性
X1 = np.random.multivariate_normal(mean1, cov1, N1) #生成N1个符合多元正态分布和设定均值/协方差的二维数据点
c1 = ['red'] * len(X1) #第一类数据点绘制为红色

mean2 = (14, 18)
cov2 = np.array([[sigma, 0], [0, sigma]])
X2 = np.random.multivariate_normal(mean2, cov2, N2)
c2 = ['blue'] * len(X2)

X = np.concatenate((X1, X2)) #合并两类数据，在这里就是直接将x2数据拼接到x1后面
color = np.concatenate((c1, c2))

T = [] #定义分类列表
for n in range(0, len(X)):
    if n < len(X1):
        T.append(0) #第一类数据分类为0
    else:
        T.append(1) #第二类数据分类为1

plt.scatter(X[:, 0], X[:, 1], marker = 'o', c = color) #X[:, 0]表示对一个二维数组。取第一维中的所有数据，第二维中取第0个数据
plt.show()

np.save('class1.npy', X1)
np.save('class2.npy', X2)
io.savemat('class1.mat', {'class1': X1})
io.savemat('class2.mat', {'class2': X2})